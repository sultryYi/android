package com.example.sliding.student;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sliding.R;

public class QuestionOrForestActivity extends AppCompatActivity {
    private static final String TAG = "QuestionOrForestActivity";
    private float startY;
    private float currentY;
    private float moveY;
    private float windowY;
    private ViewGroup questionSlideView;
    private ViewGroup forestSlideView;
    private LinearLayout question;
    private LinearLayout forest;
    private long backTime;
    private long twoBackTime;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_questionorforest);

        backTime = 0;
        twoBackTime = 0;
        question = (LinearLayout) this.findViewById(R.id.questionTextView);
        forest = (LinearLayout) this.findViewById(R.id.forestTextView);
        startY = 0;
        currentY = 0;
        moveY = 0;
        Point point = new Point();
        this.getWindowManager().getDefaultDisplay().getRealSize(point);
        windowY = point.y;
        questionSlideView = (ViewGroup) question;
        forestSlideView = (ViewGroup) forest;

        //measure the height of forest
        int w = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        forestSlideView.measure(w, h);
        int height = forestSlideView.getMeasuredHeight();

        questionSlideView.setPivotX(getWindowManager().getDefaultDisplay().getWidth()/2);
        questionSlideView.setPivotY(0);
        forestSlideView.setPivotX(getWindowManager().getDefaultDisplay().getWidth()/2);
        forestSlideView.setPivotY(height);

        initStatusBar();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event){
        Intent intent = null;
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                startY = event.getY();
                break;

            case MotionEvent.ACTION_MOVE:
                currentY = event.getY();
                moveY = currentY - startY;
                if(moveY > 0 && (1 + 6 * moveY / windowY) * forestSlideView.getPivotY() <= windowY){//move down side, control the question
                    questionSlideView.bringToFront();
                    questionSlideView.setScaleX(1 + 6 * moveY / windowY);
                    questionSlideView.setScaleY(1 + 6 * moveY / windowY);
                }else if(moveY < 0 && (1 - 6 * moveY / windowY) * forestSlideView.getPivotY() <= windowY){//move up side
                    forestSlideView.bringToFront();
                    forestSlideView.setScaleX(1 - 6 * moveY / windowY);
                    forestSlideView.setScaleY(1 - 6 * moveY / windowY);
                }else {
                    break;
                }
                break;

            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                if(moveY > 0) {
                    question.animate()
                            .scaleX(1)
                            .scaleY(1)
                            .setDuration(200);
                    if(moveY/windowY >= 0.3){
                        intent = new Intent(this, QuestionActivity.class);
                        intent.putExtra("username",this.getIntent().getStringExtra("username"));
                        intent.putExtra("password",this.getIntent().getStringExtra("password"));
                        this.startActivity(intent);
                    }
                }else if(moveY < 0){
                    forest.animate()
                            .scaleX(1)
                            .scaleY(1)
                            .setDuration(200);
                    if(moveY/windowY <= -0.3){
                        intent = new Intent(this, ForestActivity.class);
                        this.startActivity(intent);
                    }
                }else {
                    break;
                }
                break;
        }

        return super.dispatchTouchEvent(event);
    }

    private void initStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView()
                    .setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    @Override
    public void onBackPressed(){
        if(twoBackTime == 0) {
            Toast.makeText(this, "再按一次返回键注销登录", Toast.LENGTH_SHORT).show();
            backTime = System.currentTimeMillis();
            twoBackTime = System.currentTimeMillis() + 5000;
        }else {
            twoBackTime = System.currentTimeMillis();
            if(twoBackTime - backTime <= 2000){
                Toast.makeText(this, "登出成功", Toast.LENGTH_SHORT).show();
                this.finish();
            }else {
                Toast.makeText(this, "再按一次返回键注销登录", Toast.LENGTH_SHORT).show();
                backTime = System.currentTimeMillis();
                twoBackTime = System.currentTimeMillis() + 5000;
            }
        }
    }
}
