package com.example.sliding;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;
import android.widget.Toast;

import com.example.sliding.student.LoginDialog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class WelcomeActivity extends AppCompatActivity {
    private static final String TAG = "WelcomeActivity";
    static final String databaseName = "database";
    static final String currentUserTable = "currentUserTable";
    private Cursor cursor;
    SQLiteDatabase db;
    private float downX;
    private float downY;
    private float moveX;
    private float moveY;
    private float movePercent;
    private ViewGroup mSlideView;
    private Scroller mScroller;
    private Handler mHandler;
    private long backTime;
    private long twoBackTime;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        backTime = 0;
        twoBackTime = 0;
        db = openOrCreateDatabase(databaseName, Context.MODE_PRIVATE, null);
        cursor = db.rawQuery("SELECT * FROM "+currentUserTable,null);
        mSlideView = (ViewGroup) this.getWindow().getDecorView();
        mSlideView.setPivotX(this.getWindowManager().getDefaultDisplay().getWidth()/2);
        mSlideView.setPivotY(this.getWindowManager().getDefaultDisplay().getHeight());
        mScroller = new Scroller(this,new DecelerateInterpolator());
        mHandler = new Handler(){

            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what){
                    case 1://student
                        View stuView = getLayoutInflater().inflate(R.layout.dialog_login, null);
                        LoginDialog stuLoginDialog = new LoginDialog(WelcomeActivity.this, 0, 0, stuView, R.style.DialogTheme, db);
                        stuLoginDialog.setCancelable(true);
                        stuLoginDialog.show();
                        break;
                    case 2://teacher
                        View teaView = getLayoutInflater().inflate(R.layout.dialog_login, null);
                        LoginDialog teaLoginDialog = new LoginDialog(WelcomeActivity.this, 0, 0, teaView, R.style.DialogTheme, db);
                        teaLoginDialog.setCancelable(true);
                        teaLoginDialog.show();
                        break;
                }
            }
        };
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        initStatusBar();

//        Thread thread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                String strUrl = "http://49.234.213.234/login";
//                String name = "student1";
//                String pwd = "123";
//                StringBuffer sb = new StringBuffer();
//                loginUrl(strUrl, name, pwd, sb);
//            }
//        });
//        thread.start();
    }

//    public void loginUrl(String strUrl, String name, String pwd, StringBuffer sb) {
//        String temp;
//        try {
//            //做连接，以及各连接参数的设置
//            URL url = new URL(strUrl+"?name="+name+"&pass="+pwd);// 根据自己的服务器地址填写
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            Log.w(TAG, url.toString());
//            conn.setRequestMethod("GET");
////                    conn.setDoOutput(true);
//            conn.setDoInput(true);
//            //向服务器发出请求时带的参数
//            StringBuffer param = new StringBuffer();
//            param.append("name=").append("student1");
//            param.append("&pass=").append("123");
//            //将参数写入
//            conn.getOutputStream().write(param.toString().getBytes("UTF-8"));
//            Log.w(TAG, conn.toString());
//            //发起请求
//            conn.connect();
//            //接收响应信息
//            InputStream is = conn.getInputStream();
//            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));// 获取输入流
//            while ((temp = in.readLine()) != null) {
//                sb.append(temp);
//            }
//            in.close();
//        } catch (MalformedURLException me) {
//            System.err.println("你输入的URL格式有问题！");
//            me.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        switch (ev.getAction()){
            case MotionEvent.ACTION_DOWN:
                downX = ev.getX();
                downY = ev.getY();
                Log.w(TAG,"down");
                break;
            case MotionEvent.ACTION_MOVE:
                moveX = ev.getX();
                moveY = ev.getY();
                movePercent = (moveX-downX)/this.getWindowManager().getDefaultDisplay().getWidth();
                mSlideView.setRotation(30*movePercent);
                mSlideView.setTranslationX(120*movePercent);
                break;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                Thread syncTask = new Thread() {
                    @Override
                    public void run() {
                        if(movePercent>=0.7){
                            //if the percent >= 0.7, slide right and then come back and then start the student login dialog
                            while (movePercent >= 0) {
                                mSlideView.setRotation(30 * movePercent);
                                mSlideView.setTranslationX(120 * movePercent);
                                movePercent = movePercent - 0.001f;
                                mSlideView.postInvalidate();
                                Log.d(TAG, "movePercent");
                            }

                            //start the stuLoginDialog
                            Message msg =Message.obtain();
                            msg.what = 1;   //标志消息的标志
                            mHandler.sendMessage(msg);

                        } else if(movePercent>=0) {
                            //if the 0<=percent<0.7, slide right and come back to origin
                            while (movePercent >= 0) {
                                mSlideView.setRotation(30 * movePercent);
                                mSlideView.setTranslationX(120 * movePercent);
                                movePercent = movePercent - 0.001f;
                                mSlideView.postInvalidate();
                                Log.d(TAG, "movePercent");
                            }
                        }else if(movePercent<=-0.7){
                            //if the percent<=-0.7, slide left and then come back and then start the teacher login dialog
                            while (movePercent <= 0) {
                                mSlideView.setRotation(30 * movePercent);
                                mSlideView.setTranslationX(120 * movePercent);
                                movePercent = movePercent + 0.001f;
                                mSlideView.postInvalidate();
                                Log.d(TAG, "movePercent");
                            }

                            //start the teaLoginDialog
                            Message msg =Message.obtain();
                            msg.what = 2;   //标志消息的标志
                            mHandler.sendMessage(msg);
                        }else {
                            //if -0.7<percent<0, slide left and come back to origin
                            while (movePercent <= 0) {
                                mSlideView.setRotation(30 * movePercent);
                                mSlideView.setTranslationX(120 * movePercent);
                                movePercent = movePercent + 0.001f;
                                mSlideView.postInvalidate();
                                Log.d(TAG, "movePercent");
                            }
                        }
                    }
                };
                syncTask.start();

                break;

        }

        return super.dispatchTouchEvent(ev);
    }

    private void initStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView()
                    .setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    @Override
    public void onBackPressed(){
        if(twoBackTime == 0) {
            Toast.makeText(this, "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();
            backTime = System.currentTimeMillis();
            twoBackTime = System.currentTimeMillis() + 5000;
        }else {
            twoBackTime = System.currentTimeMillis();
            if(twoBackTime - backTime <= 2000){
                this.finish();
                System.exit(0);
            }else {
                Toast.makeText(this, "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();
                backTime = System.currentTimeMillis();
                twoBackTime = System.currentTimeMillis() + 5000;
            }
        }
    }
}
