package com.example.sliding.student;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.Editable;
import android.text.method.KeyListener;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sliding.MainActivity;
import com.example.sliding.R;

public class AddQuestionDialog extends Dialog implements DialogInterface.OnKeyListener {

    public AddQuestionDialog(Context context, int width, int height, View layout, int style){
        super(context,style);
        setContentView(layout);
        if (context instanceof Activity) {
            setOwnerActivity((Activity) context);
        }


        Window window = getWindow();
        WindowManager.LayoutParams params = null;
        if (window != null) {
            params = window.getAttributes();
            params.gravity = Gravity.CENTER;
            window.setAttributes(params);
        }
    }

    @Override
    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        System.out.println(i);
        System.out.println(keyEvent);
        Toast toast = Toast.makeText(this.getContext(),"onKey",Toast.LENGTH_SHORT);
        toast.show();
        if(i == KeyEvent.KEYCODE_M){
            toast = Toast.makeText(this.getContext(),"input enter",Toast.LENGTH_SHORT);
            toast.show();
        }
        return false;
    }

}
