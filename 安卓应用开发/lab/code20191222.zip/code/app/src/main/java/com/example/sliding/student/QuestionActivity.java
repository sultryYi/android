package com.example.sliding.student;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.sliding.R;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class QuestionActivity extends AppCompatActivity implements View.OnClickListener{
    private Button mButton;
    private HorizontalScrollView mScrollView;
    private LinearLayout mLayout;
    private List<String> questions;
    private List<TextView> textViews;
    private LinearLayout.LayoutParams textViewLayoutParams;
    private LinearLayout.LayoutParams viewLayoutParams;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_question);
        mButton = (Button) findViewById(R.id.addQuestion);
        mScrollView = (HorizontalScrollView) findViewById(R.id.mScrollView);
        mLayout = (LinearLayout) findViewById(R.id.textViews);
        questions = new ArrayList<>();
        textViews = new ArrayList<>();

        //init the question list
        for(int i = 0; i<5; i++){
            String temp = ""+i;
            String question = "";
            for(int j = 0; j<50;j++)
                question+=temp;
            questions.add(question);
        }

        //init the TextView list with the list of question
        View mView = getLayoutInflater().inflate(R.layout.view_empty, null);
        mLayout.addView(mView);
        viewLayoutParams = (LinearLayout.LayoutParams) mView.getLayoutParams();
        viewLayoutParams.width = 53;
        viewLayoutParams.height = 1365;
        mView.setLayoutParams(viewLayoutParams);
        Iterator<String> iterator = questions.iterator();
        while(iterator.hasNext()){
            String question = iterator.next();
            TextView questionTextView;
            questionTextView = (TextView)getLayoutInflater().inflate(R.layout.textview_student_question,null);
//            questionTextView = (TextView) getLayoutInflater().inflate(R.layout.textview_student_question,mLayout,true);
            questionTextView.setText(question);
            questionTextView.setMovementMethod(ScrollingMovementMethod.getInstance());

            mLayout.addView(questionTextView);
            textViewLayoutParams = (LinearLayout.LayoutParams) questionTextView.getLayoutParams();
            textViewLayoutParams.width = 709;
            textViewLayoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            textViewLayoutParams.setMargins(0,210,0,0);
            questionTextView.setLayoutParams(textViewLayoutParams);

            mView = getLayoutInflater().inflate(R.layout.view_empty, null);
            mLayout.addView(mView);
            viewLayoutParams = (LinearLayout.LayoutParams) mView.getLayoutParams();
            viewLayoutParams.width = 53;
            viewLayoutParams.height = 1365;
            mView.setLayoutParams(viewLayoutParams);

//            getLayoutInflater().inflate(R.layout.view_empty, mLayout,true);

            textViews.add(questionTextView);
        }

        initStatusBar();
        mButton.setOnClickListener(this);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    private void initStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView()
                    .setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.addQuestion:
                View stuView = getLayoutInflater().inflate(R.layout.dialog_addquestion, null);
                AddQuestionDialog stuLoginDialog = new AddQuestionDialog(QuestionActivity.this, 0, 0, stuView, R.style.DialogTheme);
                stuLoginDialog.setCancelable(true);
                stuLoginDialog.show();
        }
    }
}
